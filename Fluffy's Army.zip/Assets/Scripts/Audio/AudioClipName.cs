using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum AudioClipName
{
    Music,
    Died,
    ButtonClicked,
    Jump,
    Shoot
}
