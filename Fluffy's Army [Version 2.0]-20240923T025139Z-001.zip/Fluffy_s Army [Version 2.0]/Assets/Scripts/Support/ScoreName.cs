using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum ScoreName
{
    highScore1,
    highScore2,
    highScore3,
    highScore4,
    highScore5
}
