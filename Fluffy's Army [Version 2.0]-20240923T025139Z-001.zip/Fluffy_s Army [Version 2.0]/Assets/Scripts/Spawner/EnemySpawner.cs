using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    [SerializeField] GameObject[] EnemyTypes;
    [SerializeField] GameObject ChickenBoss;
    Timer spawnTimer;
    float spawnTime;
    int enemyIndex;

    void Start()
    {
        spawnTime = Random.Range(ConfigurationUtils.EnemySpawnTimeMin, ConfigurationUtils.EnemySpawnTimeMax);
        spawnTimer = gameObject.AddComponent<Timer>();
        spawnTimer.Duration = spawnTime;
        spawnTimer.Run();

        EventManager.AddListener(EventName.levelIncrease, LevelIncrease);
    }
    void Update()
    {
        if (spawnTimer.Finished)
        {
            enemyIndex = Random.Range(0, EnemyTypes.Length);
            spawnTime = Random.Range(ConfigurationUtils.EnemySpawnTimeMin, ConfigurationUtils.EnemySpawnTimeMax);
            spawnTimer.Duration = spawnTime;
            spawnTimer.Run();
            Instantiate(EnemyTypes[enemyIndex]);
        }
    }

    void LevelIncrease(int level)
    {
        if (level % 5 == 0)
        {
            EventInvokerUtils.Invoke(EventName.bossSpawned);
            Instantiate(ChickenBoss);
        }
    }
}
