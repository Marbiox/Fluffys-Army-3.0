using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SawSpawner : MonoBehaviour
{

    [SerializeField] GameObject saw;

    List<Vector2> spawnPositions = new List<Vector2>();
    List<Vector2> sawPositions = new List<Vector2>();

    Timer spawnTimer;

    void Start()
    {
        //set spawnTimer
        spawnTimer = gameObject.AddComponent<Timer>();
        spawnTimer.Duration = ConfigurationUtils.SawSpawnFrequency;
        spawnTimer.Run();


        //sets variables
        float colliderWidth = saw.GetComponent<CircleCollider2D>().radius * 2;
        float colliderHeight = saw.GetComponent<CircleCollider2D>().radius * 2;
        float space = .1f;

        //creates spawnPlaces list
        float length = colliderWidth * transform.localScale.x + space;
        float worldWidth = ScreenUtils.ScreenRight - ScreenUtils.ScreenLeft;
        int amount = (int)(worldWidth / length);
        float offset = (worldWidth - space) % length / (amount + 1);
        length += offset;
        Vector2 spawnPlace = new Vector2(ScreenUtils.ScreenLeft + colliderWidth / 2 + offset + space, ScreenUtils.ScreenTop + colliderHeight / 2);
        for (int i = 0; i < amount; i++)
        {
            spawnPositions.Add(spawnPlace);
            spawnPlace.x += length;
        }
    }

    void Update()
    {
        if (spawnTimer.Finished)
        {
            SpawnSaws();
            spawnTimer.Duration = ConfigurationUtils.SawSpawnFrequency;
            spawnTimer.Run();
        }
    }

    void SpawnSaws()
    {
        sawPositions.Clear();
        int amount = Random.Range(ConfigurationUtils.SawSpawnMin, ConfigurationUtils.SawSpawnMax);
        sawPositions.AddRange(spawnPositions);
        for (int i = 0; i < amount; i++)
        {
            int index = Random.Range(0, sawPositions.Count);
            Vector2 location = sawPositions[index];
            Instantiate(saw,location,Quaternion.identity);
            sawPositions.RemoveAt(index);
        }
    }
}
